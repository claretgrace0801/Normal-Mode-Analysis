import numpy as np
from classes import Frequencies, Hessian, Molecule


if __name__ == "__main__":
    with open("water.xyz") as f:
        mol = Molecule(f, "Angstrom")
        mol.bohr()
        hessian = Hessian(mol, 0.00001)
        hessian.write_Hessian()
    with open("water.xyz", "r") as f:
        mol = Molecule(f)
        hessian = open("hessian.dat", "r").read()
        freq = Frequencies(mol, hessian)
        freq.frequency_output("modes.xyz")
